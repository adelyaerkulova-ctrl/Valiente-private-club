export type Gender = "men" | "women" | "unisex";
export type Family = "fresh" | "sweet" | "woody" | "oriental";
export type Season = "summer" | "winter";

export interface Volume {
  ml: number;
  price: number;
}

export interface Product {
  id: number;
  slug: string;
  brand: string;
  name: string;
  concentration: string;
  gender: Gender;
  families: Family[];
  seasons: Season[];
  topNotes: string[];
  heartNotes: string[];
  baseNotes: string[];
  longevity: string;
  longevityLevel: number; // 1-5
  sillage: string;
  sillageLevel: number; // 1-5
  suitFor: string;
  description: string;
  volumes: Volume[];
  popular?: boolean;
  isNew?: boolean;
  premium?: boolean;
}
