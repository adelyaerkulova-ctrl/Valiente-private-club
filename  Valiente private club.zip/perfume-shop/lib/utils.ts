import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatPrice(price: number): string {
  return new Intl.NumberFormat("ru-RU").format(price) + " ₸";
}

export const genderLabels: Record<string, string> = {
  men: "Мужской",
  women: "Женский",
  unisex: "Унисекс",
};

export const familyLabels: Record<string, string> = {
  fresh: "Свежие",
  sweet: "Сладкие",
  woody: "Древесные",
  oriental: "Восточные",
};

export const seasonLabels: Record<string, string> = {
  summer: "Летние",
  winter: "Зимние",
};
