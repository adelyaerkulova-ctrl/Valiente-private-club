import Link from "next/link";

export default function NotFound() {
  return (
    <div className="container-x py-32 text-center">
      <p className="eyebrow">404</p>
      <h1 className="mt-4 font-display text-4xl md:text-6xl">Страница не найдена</h1>
      <p className="mt-4 text-stone">Похоже, такого аромата или страницы не существует.</p>
      <Link href="/catalog" className="btn-primary mt-10 inline-flex">
        Вернуться в каталог
      </Link>
    </div>
  );
}
