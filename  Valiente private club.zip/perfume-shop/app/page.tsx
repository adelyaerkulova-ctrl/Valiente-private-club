import Link from "next/link";
import { Hero } from "@/components/Hero";
import { Advantages } from "@/components/Advantages";
import { Reviews } from "@/components/Reviews";
import { FAQ } from "@/components/FAQ";
import { ProductCard } from "@/components/ProductCard";
import { Reveal } from "@/components/Reveal";
import { getPopular, getNew, products } from "@/lib/products";

export default function HomePage() {
  const popular = getPopular();
  const fresh = getNew();

  return (
    <>
      <Hero />

      <section id="populyarnye" className="py-24 md:py-32 hairline border-t">
        <div className="container-x">
          <Reveal className="flex flex-col md:flex-row md:items-end md:justify-between gap-6">
            <div>
              <p className="eyebrow">Бестселлеры</p>
              <h2 className="mt-4 font-display text-3xl md:text-5xl">Популярные ароматы</h2>
            </div>
            <Link href="/catalog" className="btn-outline w-fit">
              Весь каталог
            </Link>
          </Reveal>

          <div className="mt-14 grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-x-6 gap-y-14">
            {popular.slice(0, 8).map((p, i) => (
              <ProductCard key={p.id} product={p} index={i} />
            ))}
          </div>
        </div>
      </section>

      <section id="novinki" className="py-24 md:py-32 hairline border-t bg-haze/50 dark:bg-nightpaper/40">
        <div className="container-x">
          <Reveal>
            <p className="eyebrow">Только что в каталоге</p>
            <h2 className="mt-4 font-display text-3xl md:text-5xl">Новинки сезона</h2>
          </Reveal>

          <div className="mt-14 grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-x-6 gap-y-14">
            {(fresh.length ? fresh : products.slice(0, 4)).map((p, i) => (
              <ProductCard key={p.id} product={p} index={i} />
            ))}
          </div>
        </div>
      </section>

      <Advantages />
      <Reviews />
      <FAQ />
    </>
  );
}
