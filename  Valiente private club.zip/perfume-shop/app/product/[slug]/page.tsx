import { notFound } from "next/navigation";
import type { Metadata } from "next";
import Link from "next/link";
import { products, getProductBySlug } from "@/lib/products";
import { genderLabels, familyLabels, seasonLabels } from "@/lib/utils";
import { ScentGlyph } from "@/components/ScentGlyph";
import { ScentProfile } from "@/components/ScentProfile";
import { BuyPanel } from "@/components/BuyPanel";
import { ProductCard } from "@/components/ProductCard";
import { Reveal } from "@/components/Reveal";

export function generateStaticParams() {
  return products.map((p) => ({ slug: p.slug }));
}

export function generateMetadata({ params }: { params: { slug: string } }): Metadata {
  const product = getProductBySlug(params.slug);
  if (!product) return {};
  return {
    title: `${product.brand} ${product.name}`,
    description: product.description,
  };
}

export default function ProductPage({ params }: { params: { slug: string } }) {
  const product = getProductBySlug(params.slug);
  if (!product) notFound();

  const related = products
    .filter((p) => p.id !== product.id && p.families.some((f) => product.families.includes(f)))
    .slice(0, 4);

  return (
    <div className="container-x py-10 md:py-16">
      <nav className="text-xs text-stone flex items-center gap-2">
        <Link href="/" className="hover:text-gold transition-colors">Главная</Link>
        <span>/</span>
        <Link href="/catalog" className="hover:text-gold transition-colors">Каталог</Link>
        <span>/</span>
        <span className="text-ink dark:text-haze">{product.brand} {product.name}</span>
      </nav>

      <div className="mt-8 grid grid-cols-1 lg:grid-cols-2 gap-14">
        <Reveal className="lg:sticky lg:top-28 lg:self-start">
          <div className="aspect-[4/5] bg-haze dark:bg-nightpaper hairline border p-10 md:p-16">
            <ScentGlyph families={product.families} />
          </div>
        </Reveal>

        <div>
          <Reveal>
            <div className="text-[11px] uppercase tracking-widest2 text-stone">{product.brand}</div>
            <h1 className="mt-2 font-display text-4xl md:text-5xl leading-tight">{product.name}</h1>
            <div className="mt-3 flex flex-wrap gap-x-4 gap-y-1 text-sm text-stone">
              <span>{product.concentration}</span>
              <span>·</span>
              <span>{genderLabels[product.gender]}</span>
              <span>·</span>
              <span>{product.seasons.map((s) => seasonLabels[s]).join(" / ")}</span>
            </div>

            <p className="mt-6 text-base md:text-lg leading-relaxed text-ink/85 dark:text-haze/85 max-w-xl">
              {product.description}
            </p>

            <div className="mt-4 flex flex-wrap gap-2">
              {product.families.map((f) => (
                <span key={f} className="hairline border px-3 py-1.5 text-[11px] uppercase tracking-widest2 text-stone">
                  {familyLabels[f]}
                </span>
              ))}
            </div>
          </Reveal>

          <Reveal delay={0.1} className="mt-10 hairline border-t pt-10">
            <BuyPanel product={product} />
          </Reveal>

          <Reveal delay={0.15} className="mt-14 hairline border-t pt-10">
            <p className="eyebrow mb-6">Пирамида аромата</p>
            <ScentProfile product={product} />
          </Reveal>

          <Reveal delay={0.2} className="mt-10 hairline border-t pt-10">
            <p className="eyebrow mb-3">Кому подойдёт</p>
            <p className="text-sm md:text-base leading-relaxed text-stone max-w-xl">{product.suitFor}</p>
          </Reveal>
        </div>
      </div>

      {related.length > 0 && (
        <section className="mt-28">
          <Reveal>
            <p className="eyebrow">Похожие ароматы</p>
            <h2 className="mt-4 font-display text-3xl md:text-4xl">Вам также может понравиться</h2>
          </Reveal>
          <div className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-x-6 gap-y-14">
            {related.map((p, i) => (
              <ProductCard key={p.id} product={p} index={i} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
