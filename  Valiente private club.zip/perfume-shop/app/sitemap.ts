import { MetadataRoute } from "next";
import { products } from "@/lib/products";

const BASE_URL = "https://aroma-house.kz";

export default function sitemap(): MetadataRoute.Sitemap {
  const staticRoutes = ["", "/catalog"].map((path) => ({
    url: `${BASE_URL}${path}`,
    lastModified: new Date(),
  }));

  const productRoutes = products.map((p) => ({
    url: `${BASE_URL}/product/${p.slug}`,
    lastModified: new Date(),
  }));

  return [...staticRoutes, ...productRoutes];
}
