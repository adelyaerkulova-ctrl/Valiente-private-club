import { Suspense } from "react";
import type { Metadata } from "next";
import { CatalogClient } from "@/components/CatalogClient";

export const metadata: Metadata = {
  title: "Каталог ароматов",
  description:
    "Полный каталог оригинальной парфюмерии: мужские, женские и унисекс ароматы, поиск и фильтры по сезону, характеру и цене.",
};

export default function CatalogPage() {
  return (
    <Suspense fallback={<div className="container-x py-24" />}>
      <CatalogClient />
    </Suspense>
  );
}
