import type { Metadata } from "next";
import { Bodoni_Moda, Inter } from "next/font/google";
import "./globals.css";
import { ThemeProvider } from "@/components/ThemeProvider";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";

const display = Bodoni_Moda({
  subsets: ["latin", "cyrillic"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-display",
  display: "swap",
});

const body = Inter({
  subsets: ["latin", "cyrillic"],
  weight: ["300", "400", "500", "600"],
  variable: "--font-body",
  display: "swap",
});

export const metadata: Metadata = {
  metadataBase: new URL("https://aroma-house.kz"),
  title: {
    default: "AROMA HOUSE — Оригинальная нишевая и селективная парфюмерия",
    template: "%s — AROMA HOUSE",
  },
  description:
    "Магазин оригинальной парфюмерии в Казахстане: Dior, Chanel, Tom Ford, Louis Vuitton, Creed, Roja Parfums и другие дома. Только проверенные ароматы, быстрая и надёжная доставка.",
  keywords: [
    "оригинальная парфюмерия",
    "духи Казахстан",
    "распив парфюмерии",
    "Dior Sauvage",
    "Baccarat Rouge 540",
    "Tom Ford",
    "нишевая парфюмерия",
  ],
  openGraph: {
    title: "AROMA HOUSE — Оригинальная парфюмерия",
    description: "Только проверенные ароматы. Доставка по Казахстану.",
    type: "website",
    locale: "ru_RU",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="ru" suppressHydrationWarning>
      <body
        className={`${display.variable} ${body.variable} font-body bg-paper text-ink dark:bg-night dark:text-haze antialiased selection:bg-ink selection:text-paper dark:selection:bg-haze dark:selection:text-night transition-colors duration-500`}
      >
        <ThemeProvider>
          <Header />
          <main>{children}</main>
          <Footer />
        </ThemeProvider>
      </body>
    </html>
  );
}
