"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ThemeToggle } from "./ThemeToggle";

const links = [
  { href: "/catalog", label: "Каталог" },
  { href: "/#populyarnye", label: "Популярное" },
  { href: "/#novinki", label: "Новинки" },
  { href: "/#otzyvy", label: "Отзывы" },
  { href: "/#faq", label: "FAQ" },
];

export function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`sticky top-0 z-50 transition-all duration-500 ease-silk ${
        scrolled
          ? "bg-paper/90 dark:bg-night/90 backdrop-blur-md hairline border-b"
          : "bg-transparent"
      }`}
    >
      <div className="container-x flex items-center justify-between h-20">
        <Link
          href="/"
          className="font-display text-xl md:text-2xl tracking-[0.18em] uppercase"
        >
          Aroma House
        </Link>

        <nav className="hidden md:flex items-center gap-10">
          {links.map((l) => (
            <Link
              key={l.href}
              href={l.href}
              className="text-[11px] uppercase tracking-widest2 text-stone hover:text-ink dark:hover:text-haze transition-colors duration-300"
            >
              {l.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          <Link
            href="/catalog"
            className="hidden sm:inline-flex h-9 w-9 items-center justify-center hairline border rounded-full hover:border-gold transition-colors duration-500"
            aria-label="Поиск по каталогу"
          >
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none">
              <circle cx="11" cy="11" r="7" className="stroke-ink dark:stroke-haze" strokeWidth="1.6" />
              <path d="M21 21l-4.3-4.3" className="stroke-ink dark:stroke-haze" strokeWidth="1.6" strokeLinecap="round" />
            </svg>
          </Link>
          <ThemeToggle />
          <button
            onClick={() => setOpen(true)}
            className="md:hidden h-9 w-9 flex items-center justify-center hairline border rounded-full"
            aria-label="Открыть меню"
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
              <path d="M3 6h18M3 12h18M3 18h18" className="stroke-ink dark:stroke-haze" strokeWidth="1.6" strokeLinecap="round" />
            </svg>
          </button>
        </div>
      </div>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[60] bg-paper dark:bg-night md:hidden"
          >
            <div className="container-x flex items-center justify-between h-20">
              <span className="font-display text-xl tracking-[0.18em] uppercase">Aroma House</span>
              <button
                onClick={() => setOpen(false)}
                className="h-9 w-9 flex items-center justify-center hairline border rounded-full"
                aria-label="Закрыть меню"
              >
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                  <path d="M6 6l12 12M18 6L6 18" className="stroke-ink dark:stroke-haze" strokeWidth="1.6" strokeLinecap="round" />
                </svg>
              </button>
            </div>
            <motion.nav
              initial="hidden"
              animate="show"
              variants={{ show: { transition: { staggerChildren: 0.06 } } }}
              className="container-x mt-10 flex flex-col gap-6"
            >
              {links.map((l) => (
                <motion.div
                  key={l.href}
                  variants={{
                    hidden: { opacity: 0, y: 16 },
                    show: { opacity: 1, y: 0 },
                  }}
                >
                  <Link
                    href={l.href}
                    onClick={() => setOpen(false)}
                    className="font-display text-3xl"
                  >
                    {l.label}
                  </Link>
                </motion.div>
              ))}
            </motion.nav>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
