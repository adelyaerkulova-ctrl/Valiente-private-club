"use client";

import { Gender, Family, Season } from "@/lib/types";
import { familyLabels, seasonLabels, genderLabels } from "@/lib/utils";

export interface FilterState {
  query: string;
  genders: Gender[];
  seasons: Season[];
  families: Family[];
  price: "all" | "under50" | "under100" | "premium";
}

const genderOptions: Gender[] = ["men", "women", "unisex"];
const seasonOptions: Season[] = ["summer", "winter"];
const familyOptions: Family[] = ["fresh", "sweet", "woody", "oriental"];

function Chip({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      onClick={onClick}
      className={`px-4 py-2 text-[11px] uppercase tracking-widest2 border transition-all duration-300 ease-silk ${
        active
          ? "bg-ink text-paper border-ink dark:bg-haze dark:text-night dark:border-haze"
          : "hairline text-stone hover:text-ink dark:hover:text-haze hover:border-gold"
      }`}
    >
      {children}
    </button>
  );
}

export function Filters({
  state,
  onChange,
  resultCount,
}: {
  state: FilterState;
  onChange: (next: FilterState) => void;
  resultCount: number;
}) {
  const toggle = <T,>(arr: T[], val: T): T[] =>
    arr.includes(val) ? arr.filter((v) => v !== val) : [...arr, val];

  return (
    <div className="space-y-8">
      <div>
        <label className="eyebrow" htmlFor="search">
          Поиск
        </label>
        <div className="mt-3 relative">
          <input
            id="search"
            type="text"
            value={state.query}
            onChange={(e) => onChange({ ...state, query: e.target.value })}
            placeholder="Название или бренд…"
            className="w-full bg-transparent border-b hairline py-3 pr-8 text-sm placeholder:text-stone/60 focus:outline-none focus:border-gold transition-colors duration-300"
          />
          <svg
            width="14"
            height="14"
            viewBox="0 0 24 24"
            fill="none"
            className="absolute right-1 top-1/2 -translate-y-1/2 text-stone"
          >
            <circle cx="11" cy="11" r="7" stroke="currentColor" strokeWidth="1.6" />
            <path d="M21 21l-4.3-4.3" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
          </svg>
        </div>
      </div>

      <div>
        <div className="eyebrow mb-3">Пол</div>
        <div className="flex flex-wrap gap-2">
          {genderOptions.map((g) => (
            <Chip key={g} active={state.genders.includes(g)} onClick={() => onChange({ ...state, genders: toggle(state.genders, g) })}>
              {genderLabels[g]}
            </Chip>
          ))}
        </div>
      </div>

      <div>
        <div className="eyebrow mb-3">Сезон</div>
        <div className="flex flex-wrap gap-2">
          {seasonOptions.map((s) => (
            <Chip key={s} active={state.seasons.includes(s)} onClick={() => onChange({ ...state, seasons: toggle(state.seasons, s) })}>
              {seasonLabels[s]}
            </Chip>
          ))}
        </div>
      </div>

      <div>
        <div className="eyebrow mb-3">Характер аромата</div>
        <div className="flex flex-wrap gap-2">
          {familyOptions.map((f) => (
            <Chip key={f} active={state.families.includes(f)} onClick={() => onChange({ ...state, families: toggle(state.families, f) })}>
              {familyLabels[f]}
            </Chip>
          ))}
        </div>
      </div>

      <div>
        <div className="eyebrow mb-3">Цена</div>
        <div className="flex flex-wrap gap-2">
          <Chip active={state.price === "all"} onClick={() => onChange({ ...state, price: "all" })}>
            Все
          </Chip>
          <Chip active={state.price === "under50"} onClick={() => onChange({ ...state, price: "under50" })}>
            До 50 000 ₸
          </Chip>
          <Chip active={state.price === "under100"} onClick={() => onChange({ ...state, price: "under100" })}>
            До 100 000 ₸
          </Chip>
          <Chip active={state.price === "premium"} onClick={() => onChange({ ...state, price: "premium" })}>
            Премиум
          </Chip>
        </div>
      </div>

      <div className="pt-4 hairline border-t flex items-center justify-between">
        <span className="text-xs text-stone">Найдено: {resultCount}</span>
        <button
          onClick={() =>
            onChange({ query: "", genders: [], seasons: [], families: [], price: "all" })
          }
          className="text-[11px] uppercase tracking-widest2 text-stone hover:text-gold transition-colors duration-300"
        >
          Сбросить
        </button>
      </div>
    </div>
  );
}
