"use client";

import { motion } from "framer-motion";
import { Product } from "@/lib/types";

function Gauge({ label, level, max = 5 }: { label: string; level: number; max?: number }) {
  return (
    <div>
      <div className="flex items-center justify-between text-[11px] uppercase tracking-widest2 text-stone">
        <span>{label}</span>
        <span>{level}/{max}</span>
      </div>
      <div className="mt-2 flex gap-1.5">
        {Array.from({ length: max }).map((_, i) => (
          <motion.span
            key={i}
            initial={{ scaleX: 0 }}
            whileInView={{ scaleX: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: i * 0.06, ease: [0.22, 1, 0.36, 1] }}
            style={{ transformOrigin: "left" }}
            className={`h-1.5 flex-1 origin-left ${
              i < level ? "bg-gold" : "bg-line dark:bg-nightline"
            }`}
          />
        ))}
      </div>
    </div>
  );
}

function NoteRow({
  label,
  notes,
  width,
  delay,
}: {
  label: string;
  notes: string[];
  width: string;
  delay: number;
}) {
  return (
    <div className="grid grid-cols-[92px_1fr] gap-4 items-start py-5 hairline border-t first:border-t-0">
      <span className="eyebrow pt-1">{label}</span>
      <div>
        <p className="text-sm md:text-base">{notes.join(" · ")}</p>
        <motion.div
          initial={{ scaleX: 0 }}
          whileInView={{ scaleX: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay, ease: [0.22, 1, 0.36, 1] }}
          style={{ width, transformOrigin: "left" }}
          className="mt-3 h-[3px] bg-gradient-to-r from-gold to-goldsoft origin-left"
        />
      </div>
    </div>
  );
}

export function ScentProfile({ product }: { product: Product }) {
  return (
    <div>
      <div>
        <NoteRow label="Верхние" notes={product.topNotes} width="90%" delay={0} />
        <NoteRow label="Средние" notes={product.heartNotes} width="65%" delay={0.15} />
        <NoteRow label="Базовые" notes={product.baseNotes} width="40%" delay={0.3} />
      </div>

      <div className="mt-10 grid grid-cols-2 gap-8">
        <Gauge label="Стойкость" level={product.longevityLevel} />
        <Gauge label="Шлейф" level={product.sillageLevel} />
      </div>
    </div>
  );
}
