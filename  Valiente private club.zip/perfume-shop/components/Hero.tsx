"use client";

import Link from "next/link";
import { motion } from "framer-motion";

export function Hero() {
  return (
    <section className="relative overflow-hidden min-h-[92vh] flex items-center border-b hairline">
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute -top-32 -left-24 h-[420px] w-[420px] rounded-full bg-goldsoft/25 blur-3xl animate-drift" />
        <div
          className="absolute bottom-[-140px] right-[-80px] h-[380px] w-[380px] rounded-full bg-stone/10 blur-3xl animate-drift"
          style={{ animationDelay: "3s" }}
        />
        <div className="absolute inset-0 bg-noise opacity-40" />
      </div>

      <div className="container-x relative w-full">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-end">
          <div className="lg:col-span-9">
            <motion.p
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
              className="eyebrow"
            >
              Selective &amp; Niche Perfumery — Kazakhstan
            </motion.p>

            <motion.h1
              initial={{ opacity: 0, y: 32 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1, delay: 0.15, ease: [0.22, 1, 0.36, 1] }}
              className="mt-6 font-display font-medium leading-[0.98] text-[13vw] sm:text-[9vw] lg:text-[5.6vw] tracking-tight"
            >
              Оригинальная
              <br />
              парфюмерия
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.9, delay: 0.4, ease: [0.22, 1, 0.36, 1] }}
              className="mt-8 max-w-md text-base md:text-lg text-stone dark:text-haze/70 leading-relaxed"
            >
              Только проверенные ароматы. Доставка по Казахстану.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.9, delay: 0.6, ease: [0.22, 1, 0.36, 1] }}
              className="mt-10 flex items-center gap-6"
            >
              <Link href="/catalog" className="btn-primary">
                Смотреть каталог
              </Link>
              <a href="#preimushchestva" className="text-[11px] uppercase tracking-widest2 text-stone hover:text-ink dark:hover:text-haze border-b border-transparent hover:border-current transition-colors duration-300 pb-1">
                Почему мы
              </a>
            </motion.div>
          </div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 0.5 }}
            className="lg:col-span-3 hidden lg:flex flex-col items-end text-right gap-2"
          >
            <span className="eyebrow">44 ароматов</span>
            <span className="eyebrow">12 домов парфюмерии</span>
            <span className="eyebrow">100% оригинал</span>
          </motion.div>
        </div>
      </div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.1, duration: 0.8 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2"
      >
        <span className="eyebrow">Листайте</span>
        <span className="h-10 w-px bg-ink/30 dark:bg-haze/30 animate-pulse" />
      </motion.div>
    </section>
  );
}
