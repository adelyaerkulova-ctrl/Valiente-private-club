"use client";

import { useMemo, useState, useEffect } from "react";
import { useSearchParams } from "next/navigation";
import { products } from "@/lib/products";
import { Filters, FilterState } from "./Filters";
import { ProductCard } from "./ProductCard";
import { Reveal } from "./Reveal";
import { Gender } from "@/lib/types";

const initialState: FilterState = {
  query: "",
  genders: [],
  seasons: [],
  families: [],
  price: "all",
};

export function CatalogClient() {
  const searchParams = useSearchParams();
  const [state, setState] = useState<FilterState>(initialState);
  const [mobileFiltersOpen, setMobileFiltersOpen] = useState(false);

  useEffect(() => {
    const gender = searchParams.get("gender") as Gender | null;
    const price = searchParams.get("price") as FilterState["price"] | null;
    if (gender || price) {
      setState((s) => ({
        ...s,
        genders: gender ? [gender] : s.genders,
        price: price ?? s.price,
      }));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const filtered = useMemo(() => {
    return products.filter((p) => {
      if (state.query) {
        const q = state.query.toLowerCase();
        if (!p.name.toLowerCase().includes(q) && !p.brand.toLowerCase().includes(q)) {
          return false;
        }
      }
      if (state.genders.length && !state.genders.includes(p.gender)) return false;
      if (state.seasons.length && !state.seasons.some((s) => p.seasons.includes(s))) return false;
      if (state.families.length && !state.families.some((f) => p.families.includes(f))) return false;

      const maxPrice = p.volumes[p.volumes.length - 1].price;
      if (state.price === "under50" && maxPrice > 50000) return false;
      if (state.price === "under100" && maxPrice > 100000) return false;
      if (state.price === "premium" && !p.premium) return false;

      return true;
    });
  }, [state]);

  return (
    <div className="container-x py-12 md:py-16">
      <Reveal>
        <p className="eyebrow">Каталог</p>
        <h1 className="mt-4 font-display text-4xl md:text-6xl">Все ароматы</h1>
      </Reveal>

      <div className="mt-6 flex md:hidden">
        <button
          onClick={() => setMobileFiltersOpen((v) => !v)}
          className="btn-outline w-full"
        >
          {mobileFiltersOpen ? "Скрыть фильтры" : "Показать фильтры"}
        </button>
      </div>

      <div className="mt-10 grid grid-cols-1 md:grid-cols-[260px_1fr] gap-12">
        <aside className={`${mobileFiltersOpen ? "block" : "hidden"} md:block`}>
          <div className="md:sticky md:top-28">
            <Filters state={state} onChange={setState} resultCount={filtered.length} />
          </div>
        </aside>

        <div>
          {filtered.length === 0 ? (
            <div className="py-24 text-center">
              <p className="font-display text-2xl">Ничего не найдено</p>
              <p className="mt-3 text-sm text-stone">Попробуйте изменить фильтры или поисковый запрос.</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-14">
              {filtered.map((p, i) => (
                <ProductCard key={p.id} product={p} index={i} />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
