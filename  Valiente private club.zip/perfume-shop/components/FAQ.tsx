"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Reveal } from "./Reveal";

const faqs = [
  {
    q: "Вы продаёте оригинальную парфюмерию?",
    a: "Да, весь ассортимент — 100% оригинальная продукция от официальных поставщиков. Мы не работаем с репликами и аналогами.",
  },
  {
    q: "Можно ли купить пробник небольшого объёма?",
    a: "Да, у большинства ароматов доступны объёмы 5, 10 и 20 мл — удобно, чтобы попробовать аромат перед покупкой полноразмерного флакона.",
  },
  {
    q: "Как быстро приходит заказ?",
    a: "По Алматы доставка занимает 1–2 дня, по остальному Казахстану — от 2 до 5 дней в зависимости от региона.",
  },
  {
    q: "Как проверить подлинность аромата?",
    a: "Каждый флакон сопровождается партионным кодом и упаковкой производителя. При получении вы можете свериться с официальной базой бренда.",
  },
  {
    q: "Какие способы оплаты доступны?",
    a: "Оплата картой онлайн, переводом или наличными при получении — в зависимости от региона доставки.",
  },
  {
    q: "Можно ли вернуть или обменять аромат?",
    a: "Да, если флакон не был вскрыт и сохранена упаковка — в течение 14 дней с момента получения.",
  },
];

export function FAQ() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <section id="faq" className="py-24 md:py-32 hairline border-t">
      <div className="container-x">
        <Reveal>
          <p className="eyebrow">Вопросы и ответы</p>
          <h2 className="mt-4 font-display text-3xl md:text-5xl max-w-xl">
            Частые вопросы
          </h2>
        </Reveal>

        <div className="mt-14 max-w-3xl">
          {faqs.map((item, i) => {
            const isOpen = open === i;
            return (
              <div key={item.q} className="hairline border-b">
                <button
                  onClick={() => setOpen(isOpen ? null : i)}
                  className="w-full flex items-center justify-between gap-6 py-6 text-left"
                >
                  <span className="font-display text-lg md:text-xl">{item.q}</span>
                  <span
                    className={`shrink-0 h-7 w-7 rounded-full hairline border flex items-center justify-center transition-transform duration-500 ease-silk ${
                      isOpen ? "rotate-45" : ""
                    }`}
                  >
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none">
                      <path d="M12 5v14M5 12h14" className="stroke-ink dark:stroke-haze" strokeWidth="1.6" strokeLinecap="round" />
                    </svg>
                  </span>
                </button>
                <AnimatePresence initial={false}>
                  {isOpen && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
                      className="overflow-hidden"
                    >
                      <p className="pb-6 text-sm md:text-base text-stone leading-relaxed max-w-2xl">
                        {item.a}
                      </p>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
