import Link from "next/link";

export function Footer() {
  return (
    <footer className="bg-ink text-haze dark:bg-nightpaper dark:border-t dark:border-nightline">
      <div className="container-x py-16 grid grid-cols-1 md:grid-cols-4 gap-12">
        <div>
          <div className="font-display text-2xl tracking-[0.18em] uppercase">Aroma House</div>
          <p className="mt-4 text-sm text-haze/60 leading-relaxed max-w-xs">
            Оригинальная селективная и нишевая парфюмерия. Только проверенные
            ароматы и поставщики — доставка по всему Казахстану.
          </p>
        </div>

        <div>
          <div className="eyebrow text-haze/50">Каталог</div>
          <ul className="mt-4 space-y-3 text-sm">
            <li><Link href="/catalog?gender=men" className="hover:text-gold transition-colors">Мужская парфюмерия</Link></li>
            <li><Link href="/catalog?gender=women" className="hover:text-gold transition-colors">Женская парфюмерия</Link></li>
            <li><Link href="/catalog?gender=unisex" className="hover:text-gold transition-colors">Унисекс</Link></li>
            <li><Link href="/catalog?price=premium" className="hover:text-gold transition-colors">Премиум-линия</Link></li>
          </ul>
        </div>

        <div>
          <div className="eyebrow text-haze/50">Доставка и оплата</div>
          <ul className="mt-4 space-y-3 text-sm text-haze/80">
            <li>Доставка по Алматы — 1–2 дня</li>
            <li>Доставка по Казахстану — 2–5 дней</li>
            <li>Надёжная упаковка, трек-номер</li>
            <li>Оплата картой или при получении</li>
          </ul>
        </div>

        <div>
          <div className="eyebrow text-haze/50">Контакты</div>
          <ul className="mt-4 space-y-3 text-sm">
            <li>
              <a href="https://t.me/aromahouse_kz" target="_blank" rel="noopener noreferrer" className="hover:text-gold transition-colors">
                Telegram — @aromahouse_kz
              </a>
            </li>
            <li>
              <a href="https://instagram.com/aromahouse.kz" target="_blank" rel="noopener noreferrer" className="hover:text-gold transition-colors">
                Instagram — @aromahouse.kz
              </a>
            </li>
            <li>
              <a href="tel:+77001234567" className="hover:text-gold transition-colors">
                +7 (700) 123-45-67
              </a>
            </li>
            <li className="text-haze/60">Алматы, Казахстан</li>
          </ul>
        </div>
      </div>

      <div className="hairline border-t border-haze/10">
        <div className="container-x py-6 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-haze/40">
          <span>© {new Date().getFullYear()} Aroma House. Все права защищены.</span>
          <span>Только оригинальная продукция</span>
        </div>
      </div>
    </footer>
  );
}
