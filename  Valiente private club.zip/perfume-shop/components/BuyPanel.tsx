"use client";

import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Product } from "@/lib/types";
import { formatPrice } from "@/lib/utils";

export function BuyPanel({ product }: { product: Product }) {
  const [selected, setSelected] = useState(0);
  const [confirmed, setConfirmed] = useState(false);
  const volume = product.volumes[selected];

  const handleBuy = () => {
    setConfirmed(true);
    window.setTimeout(() => setConfirmed(false), 3200);
  };

  return (
    <div>
      <div className="eyebrow mb-3">Объём</div>
      <div className="flex flex-wrap gap-2">
        {product.volumes.map((v, i) => (
          <button
            key={v.ml}
            onClick={() => setSelected(i)}
            className={`px-5 py-3 text-sm border transition-all duration-300 ease-silk ${
              selected === i
                ? "bg-ink text-paper border-ink dark:bg-haze dark:text-night dark:border-haze"
                : "hairline text-ink dark:text-haze hover:border-gold"
            }`}
          >
            {v.ml} мл
          </button>
        ))}
      </div>

      <div className="mt-8 flex items-baseline gap-3">
        <span className="font-display text-4xl">{formatPrice(volume.price)}</span>
        <span className="text-sm text-stone">за {volume.ml} мл</span>
      </div>

      <button onClick={handleBuy} className="btn-primary mt-8 w-full sm:w-auto">
        Купить
      </button>

      <AnimatePresence>
        {confirmed && (
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            className="mt-4 text-sm text-stone"
          >
            Заявка принята — {product.brand} {product.name}, {volume.ml} мл. Мы свяжемся с вами для подтверждения заказа.
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
