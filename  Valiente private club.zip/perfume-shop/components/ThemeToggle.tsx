"use client";

import { useTheme } from "./ThemeProvider";

export function ThemeToggle() {
  const { theme, toggleTheme } = useTheme();

  return (
    <button
      onClick={toggleTheme}
      aria-label={theme === "light" ? "Включить тёмную тему" : "Включить светлую тему"}
      className="relative h-9 w-9 flex items-center justify-center hairline border rounded-full transition-colors duration-500 hover:border-gold group"
    >
      <svg
        width="16"
        height="16"
        viewBox="0 0 24 24"
        fill="none"
        className="transition-transform duration-500 group-hover:rotate-45"
      >
        {theme === "light" ? (
          <path
            d="M21 12.79A9 9 0 1111.21 3 7 7 0 0021 12.79z"
            className="stroke-ink"
            strokeWidth="1.6"
            strokeLinejoin="round"
          />
        ) : (
          <g className="stroke-haze" strokeWidth="1.6" strokeLinecap="round">
            <circle cx="12" cy="12" r="4.5" />
            <path d="M12 2v2.4M12 19.6V22M4.4 4.4l1.7 1.7M17.9 17.9l1.7 1.7M2 12h2.4M19.6 12H22M4.4 19.6l1.7-1.7M17.9 6.1l1.7-1.7" />
          </g>
        )}
      </svg>
    </button>
  );
}
