"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { Product } from "@/lib/types";
import { formatPrice, genderLabels } from "@/lib/utils";
import { ScentGlyph } from "./ScentGlyph";

export function ProductCard({ product, index = 0 }: { product: Product; index?: number }) {
  const minPrice = product.volumes[0].price;

  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-40px" }}
      transition={{ duration: 0.7, delay: (index % 8) * 0.05, ease: [0.22, 1, 0.36, 1] }}
    >
      <Link href={`/product/${product.slug}`} className="group block">
        <div className="relative aspect-[4/5] bg-haze dark:bg-nightpaper hairline border overflow-hidden rounded-sm">
          <div className="absolute top-3 left-3 z-10 flex flex-col gap-1.5">
            {product.isNew && (
              <span className="bg-ink text-paper dark:bg-haze dark:text-night text-[10px] uppercase tracking-widest2 px-2.5 py-1">
                Новинка
              </span>
            )}
            {product.popular && (
              <span className="bg-gold text-ink text-[10px] uppercase tracking-widest2 px-2.5 py-1">
                Хит
              </span>
            )}
            {product.premium && (
              <span className="border border-ink/40 dark:border-haze/40 text-[10px] uppercase tracking-widest2 px-2.5 py-1">
                Премиум
              </span>
            )}
          </div>

          <div className="absolute inset-0 p-6 transition-transform duration-700 ease-silk group-hover:scale-[1.06] group-hover:-rotate-1">
            <ScentGlyph families={product.families} />
          </div>

          <div className="absolute inset-0 bg-gradient-to-t from-black/0 via-black/0 to-black/0 group-hover:from-black/10 transition-all duration-500" />
        </div>

        <div className="mt-4 flex items-start justify-between gap-3">
          <div>
            <div className="text-[11px] uppercase tracking-widest2 text-stone">{product.brand}</div>
            <h3 className="mt-1 font-display text-lg leading-snug group-hover:text-gold transition-colors duration-300">
              {product.name}
            </h3>
            <div className="mt-1 text-xs text-stone">
              {genderLabels[product.gender]} · {product.concentration}
            </div>
          </div>
          <div className="text-right shrink-0">
            <div className="text-[10px] uppercase tracking-widest2 text-stone">от</div>
            <div className="font-medium">{formatPrice(minPrice)}</div>
          </div>
        </div>
      </Link>
    </motion.div>
  );
}
