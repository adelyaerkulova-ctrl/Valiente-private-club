import { Reveal } from "./Reveal";

const reviews = [
  {
    name: "Айгерим Т.",
    city: "Алматы",
    text: "Заказывала Baccarat Rouge 540 — пришёл быстро, упаковка на высоте, аромат полностью совпадает с оригиналом из бутика. Буду брать ещё.",
    rating: 5,
  },
  {
    name: "Данияр С.",
    city: "Астана",
    text: "Взял Dior Sauvage Elixir на пробу 10 мл — стойкость реально огромная, весь день держится. Цена намного приятнее, чем в фирменных магазинах.",
    rating: 5,
  },
  {
    name: "Мадина К.",
    city: "Шымкент",
    text: "Заказываю здесь третий раз. Каждый раз всё доходит вовремя, аккуратно упаковано, ароматы подлинные. Отдельное спасибо за консультацию по выбору.",
    rating: 5,
  },
  {
    name: "Ержан Б.",
    city: "Алматы",
    text: "Долго искал, где взять Tom Ford Lost Cherry без переплаты в 2 раза. Здесь нашёл честную цену и оригинальное качество.",
    rating: 4,
  },
];

function Stars({ rating }: { rating: number }) {
  return (
    <div className="flex gap-1">
      {Array.from({ length: 5 }).map((_, i) => (
        <svg key={i} width="13" height="13" viewBox="0 0 24 24" fill={i < rating ? "currentColor" : "none"} className="text-gold">
          <path
            d="M12 2l3.09 6.26L22 9.27l-5 4.87L18.18 21 12 17.77 5.82 21 7 14.14l-5-4.87 6.91-1.01L12 2z"
            stroke="currentColor"
            strokeWidth="1"
            strokeLinejoin="round"
          />
        </svg>
      ))}
    </div>
  );
}

export function Reviews() {
  return (
    <section id="otzyvy" className="py-24 md:py-32 hairline border-t bg-haze/50 dark:bg-nightpaper/40">
      <div className="container-x">
        <Reveal>
          <p className="eyebrow">Отзывы</p>
          <h2 className="mt-4 font-display text-3xl md:text-5xl max-w-xl">
            Что говорят наши клиенты
          </h2>
        </Reveal>

        <div className="mt-16 grid grid-cols-1 md:grid-cols-2 gap-8">
          {reviews.map((r, i) => (
            <Reveal key={r.name} delay={i * 0.08} className="bg-paper dark:bg-night p-8 md:p-10 hairline border">
              <Stars rating={r.rating} />
              <p className="mt-5 text-[15px] leading-relaxed text-ink/85 dark:text-haze/85">
                «{r.text}»
              </p>
              <div className="mt-6 text-sm">
                <span className="font-medium">{r.name}</span>
                <span className="text-stone"> · {r.city}</span>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
