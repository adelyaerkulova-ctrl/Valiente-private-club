import { Reveal } from "./Reveal";

const items = [
  {
    n: "01",
    title: "Только оригинальная продукция",
    text: "Работаем напрямую с проверенными поставщиками. Каждый флакон — подлинный товар от производителя.",
  },
  {
    n: "02",
    title: "Быстрая доставка",
    text: "Отправляем заказы в день оформления. По Алматы — 1–2 дня, по остальному Казахстану — 2–5 дней.",
  },
  {
    n: "03",
    title: "Надёжная упаковка",
    text: "Каждый заказ защищён от повреждений — флаконы доезжают в идеальном состоянии.",
  },
  {
    n: "04",
    title: "Большой выбор ароматов",
    text: "От современной классики Dior и Chanel до редких нишевых домов — Roja Parfums, Kilian, Tiziana Terenzi.",
  },
];

export function Advantages() {
  return (
    <section id="preimushchestva" className="py-24 md:py-32 hairline border-t">
      <div className="container-x">
        <Reveal>
          <p className="eyebrow">Почему мы</p>
          <h2 className="mt-4 font-display text-3xl md:text-5xl max-w-xl">
            Стандарт, которому можно доверять
          </h2>
        </Reveal>

        <div className="mt-16 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-px bg-line dark:bg-nightline">
          {items.map((item, i) => (
            <Reveal key={item.n} delay={i * 0.08} className="bg-paper dark:bg-night p-8 md:p-10">
              <span className="font-display text-3xl text-goldsoft/80">{item.n}</span>
              <h3 className="mt-6 font-display text-xl">{item.title}</h3>
              <p className="mt-3 text-sm text-stone leading-relaxed">{item.text}</p>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
