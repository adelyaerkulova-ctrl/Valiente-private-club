"use client";

import { Family } from "@/lib/types";

const familyTint: Record<Family, [string, string]> = {
  fresh: ["#DCE8E2", "#93AFA4"],
  sweet: ["#F0DAC2", "#C99B6B"],
  woody: ["#E3D2B0", "#9C7A44"],
  oriental: ["#E3C3AE", "#8B5A3C"],
};

export function ScentGlyph({
  families,
  size = "full",
  className = "",
}: {
  families: Family[];
  size?: "full" | "small";
  className?: string;
}) {
  const primary = families[0] ?? "woody";
  const [light, deep] = familyTint[primary];
  const uid = `${primary}-${light.replace("#", "")}`;

  return (
    <div className={`relative w-full h-full overflow-hidden ${className}`}>
      <svg
        viewBox="0 0 320 420"
        className="w-full h-full"
        preserveAspectRatio="xMidYMid meet"
      >
        <defs>
          <linearGradient id={`liquid-${uid}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={light} />
            <stop offset="100%" stopColor={deep} />
          </linearGradient>
          <linearGradient id={`glass-${uid}`} x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#ffffff" stopOpacity="0.55" />
            <stop offset="45%" stopColor="#ffffff" stopOpacity="0.08" />
            <stop offset="100%" stopColor="#ffffff" stopOpacity="0.3" />
          </linearGradient>
        </defs>

        {/* backdrop wash */}
        <ellipse cx="160" cy="230" rx="150" ry="150" fill={light} opacity="0.18" />

        {/* bottle cap */}
        <rect x="138" y="46" width="44" height="34" rx="3" className="fill-ink dark:fill-haze" />
        <rect x="146" y="30" width="28" height="20" rx="2" className="fill-ink dark:fill-haze" opacity="0.85" />

        {/* neck */}
        <rect x="148" y="80" width="24" height="26" fill={`url(#liquid-${uid})`} />

        {/* bottle body */}
        <path
          d="M110 106 H210 C218 106 224 112 224 122 V330 C224 352 208 366 186 366 H134 C112 366 96 352 96 330 V122 C96 112 102 106 110 106 Z"
          fill={`url(#liquid-${uid})`}
        />
        <path
          d="M110 106 H210 C218 106 224 112 224 122 V330 C224 352 208 366 186 366 H134 C112 366 96 352 96 330 V122 C96 112 102 106 110 106 Z"
          fill={`url(#glass-${uid})`}
        />
        <path
          d="M110 106 H210 C218 106 224 112 224 122 V330 C224 352 208 366 186 366 H134 C112 366 96 352 96 330 V122 C96 112 102 106 110 106 Z"
          className="stroke-ink/25 dark:stroke-haze/20"
          fill="none"
          strokeWidth="1.5"
        />

        {/* label */}
        <rect
          x="122"
          y="200"
          width="76"
          height="64"
          className="fill-paper/85 dark:fill-night/70 stroke-ink/30 dark:stroke-haze/25"
          strokeWidth="1"
        />
        <line x1="134" y1="222" x2="186" y2="222" className="stroke-ink/40 dark:stroke-haze/30" strokeWidth="1" />
        <line x1="134" y1="232" x2="186" y2="232" className="stroke-ink/25 dark:stroke-haze/20" strokeWidth="1" />
        <line x1="134" y1="242" x2="170" y2="242" className="stroke-ink/25 dark:stroke-haze/20" strokeWidth="1" />

        {/* base shadow */}
        <ellipse cx="160" cy="372" rx="58" ry="8" className="fill-ink/10 dark:fill-black/40" />
      </svg>
    </div>
  );
}
